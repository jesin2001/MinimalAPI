﻿IF NOT EXISTS (SELECT 1 FROM dbo.[User])
BEGIN
	INSERT INTO dbo.[User] (FirstName, LastName)
	VALUES
	('Jeff','Sinicki' ),
	('Juli', 'Sinicki'),
	('Jon','BonJovi'),
	('Clint','Eastwood')
END
